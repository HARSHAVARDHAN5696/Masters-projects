<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="STYLE.CSS">

    <title>Contact Us</title>
</head>
<body>
    <header>
        <div class="container">
           <a href="index.php"><img src="LOGO.webp" alt="Logo" width="200"/></a>
            <nav>
                <a href="index.php">Home</a>
                  <a href="regchavvakula.php">Mailing List</a>
                  <a href="ContactUsChavvakula.php">Contact Us</a>
                  <a href="coursereflectChavvakula.php">Course Reflection</a>
            </nav>
        </div>
    </header>
    <article>
      <div class="container">

          <?php
          // Check whether all required fields are provided
          if (isset($_GET['firstName']) && isset($_GET['lastName']) && isset($_GET['email']) && isset($_GET['message'])) {
              $firstName = $_GET['firstName'];
              $lastName = $_GET['lastName'];
              $email = $_GET['email'];
              $message = $_GET['message'];

              // Display user-provided information
              echo "<p>First Name: $firstName</p>";
              echo "<p>Last Name: $lastName</p>";
              echo "<p>Email: $email</p>";
              echo "<p>Message: $message</p>";
          } else {

          }
          ?>
      </div>
        <div class="container" style="align-items:center;">
          <h1>Contact Us</h1>
          <form action="" method="GET">
              <label for="firstName">First Name:</label>
              <input type="text" id="firstName" name="firstName" required><br><br>

              <label for="lastName">Last Name:</label>
              <input type="text" id="lastName" name="lastName" required><br><br>

              <label for="email">Email:</label>
              <input type="email" id="email" name="email" required><br><br>

              <label for="message">Message:</label><br>
               <input type="submit" name="Submit" value = "submit">
              <textarea id="message" name="message" rows="3" cols="40" required></textarea>
             <br>
              <input type="submit" name="Submit" value = "submit">
          </form>
        </div>
    </article>
    <footer>
        <div class="container">
            HARSHA VARDHAN CHAVVAKULA 2024
        </div>
    </footer>
</body>
</html>
