<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="STYLE.CSS">

    <title>Mailing List Registration</title>
</head>
<body>
    <header>
        <div class="container">
           <a href="index.php"><img src="LOGO.webp" alt="Logo" width="200"/></a>
          <nav>
              <a href="index.php">Home</a>
                <a href="regchavvakula.php">Mailing List</a>
                <a href="ContactUsChavvakula.php">Contact Us</a>
                <a href="coursereflectChavvakula.php">Course Reflection</a>
          </nav>
        </div>
    </header>
    <article>
      <div class="container">
          <h1>Mailing List Registration</h1>


        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Validatation fields
            $firstName = clean_input($_POST["firstName"]);
            $lastName = clean_input($_POST["lastName"]);
            $birthday = clean_input($_POST["birthday"]);
            $email = clean_input($_POST["email"]);

            // Echo user given information
            echo "<h2>Registration Details:</h2>";
            echo "<p>First Name: $firstName</p>";
            echo "<p>Last Name: $lastName</p>";
            echo "<p>Birthday: $birthday</p>";
            echo "<p>Email: $email</p>";
        }

        // Function to take input
        function clean_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
              <label for="firstName">First Name:</label>
              <input type="text" id="firstName" name="firstName" required><br><br>

              <label for="lastName">Last Name:</label>
              <input type="text" id="lastName" name="lastName" required><br><br>

              <label for="birthday">Birthday:</label>
              <input type="date" id="birthday" name="birthday" required><br><br>

              <label for="email">Email:</label>
              <input type="email" id="email" name="email" required>

        <input type="submit" name="Submit" value = "submit">

          </form>


      </div>
    </article>
    <footer>
      <div class="container">
          HARSHA VARDHAN CHAVVAKULA 2024
      </div>
    </footer>
</body>
</html>
