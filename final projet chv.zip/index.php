<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="STYLE.CSS">

    <title>
        HARSHA VARDHAN CHAVVAKULA
    </title>
</head>
<body>
    <header>
        <div class="container">
          <a href="index.php"><img src="LOGO.webp" alt="Logo" width="50"/></a>
          <nav>
              <a href="index.php">Home</a>
              <a href="regchavvakula.php">Mailing List</a>
              <a href="ContactUsChavvakula.php">Contact Us</a>
              <a href="coursereflectChavvakula.php">Course Reflection</a>
          </nav>
        </div>
    </header>
    <article>
        <div class="container">
          <header>
              <img src="PHOTO.jpg" alt="Your Name" width="200">
              <h1>HARSHA VARDHAN CHAVVAKULA</h1>

          </header>
          <section class="skills">
              <h2>Information and Cybersecurity Skills</h2>
              <ul>
                <li>Comprehension of network security principles</li>
                <li>Understanding encryption methods and algorithms</li>
                <li>Awareness of common cybersecurity risks and vulnerabilities</li>
                <li>Practical involvement in penetration testing and vulnerability assessment</li>
                <li>Familiarity with security best practices for web applications</li>
              </ul>
          </section>
          <section class="about">
              <h2>About Me</h2>
              <p>A motivated and adaptable individual with a passion for tackling challenges and a commitment to continuous growth. Skilled in Python, PHP, and cybersecurity principles, excelling in dynamic and fast-paced environments</p>
          </section>

          <section class="education">
              <h2>Engineering Education</h2>
              <ul>
                  <li>
                      <p>Bachelor of Engineering in Mechanical Engineering at Hindustan University</p>
                  </li>

              </ul>
          </section>
        </div>
    </article>
    <footer>
        <div class="container">
        © HARSHA VARDHAN CHAVVAKULA</div>
    </footer>
</body>
</html>